TONMOY HASAN - PERSONAL WEBSITE

Files:
- index.html: Your bilingual personal website.

How to publish it free:
1. Create/sign in to a GitHub account.
2. Create a new public repository named: tonmoy-hasan
3. Upload index.html to the repository's main/root folder.
4. Open Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch 'main' and folder '/ (root)', then Save.
7. GitHub will provide a public website URL after deployment.

Google indexing:
- Publishing does not guarantee Google listing.
- After the site is live, add its URL in Google Search Console and request indexing.
- It may take days or weeks for Google to crawl and show the page.
- Keep your public profile information accurate. Avoid publishing private phone numbers, home address, or ID numbers.

The Facebook link is the one you provided. Replace it if you later obtain your direct profile URL.
